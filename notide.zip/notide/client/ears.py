import sys, os, glob, json, time, requests

dir = sys.argv[1]
dir = os.path.realpath(dir)



# Build dirs/files tree for root dir
def tree(dir):
    list = []
    for root, subdirs, files in os.walk(dir):
        pre = root.replace(dir, '') + '/'
        for i in files:
            list.append(pre + i)

        for i in subdirs:
            list.append(pre + i + '/')

    return list



# Open file by path
def code(dir, file):
    with open(dir + file, 'r') as f:
        return {'file': file, 'code': f.read()}



# Talk to server
def talk():
    while ( True ):
        print('Checking commands from server...')

        cmd = (requests.get('https://notide.cc/api.php?pop=1').json());

        handlers = {
            'tree': lambda cmd, dir: {'tree': tree( dir )},
            'open': lambda cmd, dir: {'open': code( dir, cmd['file'] )}
        }

        out = json.dumps( handlers[cmd['cmd']](cmd, dir) )
        x = requests.post('https://notide.cc/api.php?push=1', data = out)

        # time.sleep(1)



# Enter listening mode
talk()
