<?php

echo 1;
